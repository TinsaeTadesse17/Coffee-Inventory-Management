import random

"""
Grid Cleaning Agent Implementation
Complete the agent logic following the specified rules
"""

class GridEnvironment:
    """10x10 grid environment with cleaning simulation"""
    def __init__(self):
        self.size = 10
        self.agent_position = (0, 0)
        self.performance_score = 0
        self.time_steps = 0
        self.cleaned_count = 0
        self.grid = self._initialize_grid()

    def _initialize_grid(self):
        """Create grid with random dirt and obstacles"""
        # 10x10 grid
        total_cells = self.size * self.size
        num_dirty = int(total_cells * 0.30)
        num_obstacles = int(total_cells * 0.15)
        
        # Create flat list of cell types
        cells = ['Dirty'] * num_dirty + ['Obstacle'] * num_obstacles
        # Remaining are Clean
        cells += ['Clean'] * (total_cells - len(cells))
        
        random.shuffle(cells)
        
        grid = []
        for i in range(self.size):
            grid.append(cells[i*self.size : (i+1)*self.size])
            
        # Ensure (0,0) is not an obstacle for the agent start
        if grid[0][0] == 'Obstacle':
            # Swap with first non-obstacle found
            for r in range(self.size):
                for c in range(self.size):
                    if grid[r][c] != 'Obstacle':
                        grid[0][0], grid[r][c] = grid[r][c], grid[0][0]
                        break
                else:
                    continue
                break
        
        # If (0,0) is Dirty, it stays Dirty (agent will clean it first step)
        # If (0,0) is Clean, it stays Clean
        
        return grid

    def get_agent_perception(self):
        """Return current percept for the agent"""
        x, y = self.agent_position
        percept = {
            'current_cell': self.grid[x][y],
            'adjacent_cells': {
                'north': self._get_cell_state(x-1, y),
                'south': self._get_cell_state(x+1, y),
                'east': self._get_cell_state(x, y+1),
                'west': self._get_cell_state(x, y-1)
            }
        }
        return percept

    def _get_cell_state(self, x, y):
        """Helper method to get cell state with boundary checking"""
        if 0 <= x < self.size and 0 <= y < self.size:
            return self.grid[x][y]
        return 'Boundary'

    def perform_action(self, action):
        """
        Execute the agent's action and update environment state and scores.
        """
        self.time_steps += 1
        
        if action == 'clean':
            x, y = self.agent_position
            if self.grid[x][y] == 'Dirty':
                self.grid[x][y] = 'Clean'
                self.performance_score += 10
                self.cleaned_count += 1
            else:
                # Cleaning a clean cell - no explicit penalty in prompt, but wastes a step (-1 implicit?)
                # Prompt says "-1 point for each movement action". 
                # Usually "clean" is also an action that takes time.
                # Let's assume cleaning also costs -1 or just 0? 
                # "Calculate performance metrics: ... -1 point for each movement action"
                # It doesn't say -1 for clean action. So maybe 0 cost for clean?
                # But usually every time step has a cost.
                # Let's assume only movement costs -1 as per strict reading.
                pass
                
        elif action in ['north', 'south', 'east', 'west']:
            self.performance_score -= 1 # Movement penalty
            
            dx, dy = 0, 0
            if action == 'north': dx = -1
            elif action == 'south': dx = 1
            elif action == 'east': dy = 1
            elif action == 'west': dy = -1
            
            new_x, new_y = self.agent_position[0] + dx, self.agent_position[1] + dy
            
            # Check validity
            state = self._get_cell_state(new_x, new_y)
            if state == 'Boundary' or state == 'Obstacle':
                self.performance_score -= 5 # Illegal move penalty
                # Agent stays in place
            else:
                self.agent_position = (new_x, new_y)

class ReflexCleaningAgent:
    """
    Simple reflex agent for grid cleaning
    Implement the following decision rules:

    1. If current cell is Dirty → Clean
    2. If current cell is Clean → Check adjacent cells
    3. If adjacent dirty cell exists → Move toward it
    4. If no adjacent dirty cells → Move randomly (avoid obstacles)
    5. Never move into obstacles or outside boundaries
    """

    def __init__(self):
        self.action_history = []

    def select_action(self, current_percept):
        """
        Determine next action based on current percept

        Parameters:
        current_percept: Dictionary containing 'current_cell' and 'adjacent_cells'
        
        Returns:
        String action: 'clean', 'north', 'south', 'east', 'west'
        """
        action = None
        current_cell = current_percept['current_cell']
        adj = current_percept['adjacent_cells']
        
        # 1. If current cell is Dirty → Clean
        if current_cell == 'Dirty':
            action = 'clean'
        else:
            # 2. If current cell is Clean → Check adjacent cells
            # 3. If adjacent dirty cell exists → Move toward it
            dirty_neighbors = [direction for direction, state in adj.items() if state == 'Dirty']
            
            if dirty_neighbors:
                # Pick one randomly if multiple
                action = random.choice(dirty_neighbors)
            else:
                # 4. If no adjacent dirty cells → Move randomly (avoid obstacles)
                # 5. Never move into obstacles or outside boundaries
                safe_moves = [direction for direction, state in adj.items() if state not in ['Boundary', 'Obstacle']]
                
                if safe_moves:
                    action = random.choice(safe_moves)
                else:
                    # If trapped (no safe moves), do nothing (or clean to pass time)
                    # We must return a valid action string.
                    # 'clean' is safe even if clean.
                    action = 'clean'

        self.action_history.append(action)
        return action

def run_cleaning_simulation(max_steps=200):
    """
    Run the cleaning simulation

    Parameters:
    max_steps: Maximum number of steps to simulate

    Returns:
    Dictionary containing performance metrics
    """
    environment = GridEnvironment()
    agent = ReflexCleaningAgent()

    # Optional: Visualize initial state
    # visualize_grid(environment, 0)

    for step in range(max_steps):
        percept = environment.get_agent_perception()
        action = agent.select_action(percept)
        environment.perform_action(action)
        
        # Optional: Visualize step
        # visualize_grid(environment, step + 1)

    return {
        'final_score': environment.performance_score,
        'cells_cleaned': environment.cleaned_count,
        'steps_taken': environment.time_steps
    }

def visualize_grid(environment, step_number):
    """
    Display the current grid state

    Parameters:
    environment: Current GridEnvironment instance
    step_number: Current simulation step

    Prints formatted grid representation
    """
    print(f"\nStep: {step_number} | Score: {environment.performance_score}")
    print("-" * 22)
    for r in range(environment.size):
        row_str = "|"
        for c in range(environment.size):
            if (r, c) == environment.agent_position:
                row_str += "A "
            elif environment.grid[r][c] == 'Dirty':
                row_str += "D "
            elif environment.grid[r][c] == 'Obstacle':
                row_str += "X "
            else:
                row_str += "C "
        row_str += "|"
        print(row_str)
    print("-" * 22)

if __name__ == "__main__":
    # Execute simulation and display results
    results = run_cleaning_simulation()
    print("Simulation Complete")
    print(f"Final Performance Score: {results['final_score']}")
    print(f"Cells Cleaned: {results['cells_cleaned']}")
    print(f"Steps Taken: {results['steps_taken']}")
    
    print("\n--- Performance Analysis (5 Runs) ---")
    scores = []
    cleaned = []
    for i in range(5):
        # Use a new seed for each run to get different grids
        # Note: random.seed is global, so we set it here.
        # But run_cleaning_simulation creates new env which uses random.
        # If we don't set seed, it uses time.
        # To ensure "different random seeds" as requested:
        random.seed(i * 100) 
        res = run_cleaning_simulation()
        scores.append(res['final_score'])
        cleaned.append(res['cells_cleaned'])
        print(f"Run {i+1}: Score={res['final_score']}, Cleaned={res['cells_cleaned']}")
    
    print(f"Average Score: {sum(scores)/5}")
    print(f"Average Cleaned: {sum(cleaned)/5}")
